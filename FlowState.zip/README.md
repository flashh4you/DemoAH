
  # FlowState Productivity Booster App

  This is a code bundle for FlowState Productivity Booster App. The original project is available at https://www.figma.com/design/Gs9NaiJ534vTtubVdsIZyo/FlowState-Productivity-Booster-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  