import { useState, useEffect } from 'react';
import { User, Moon, Sun, ListTodo, Smartphone, Users, Sparkles } from 'lucide-react';
import { TodoSection } from './components/TodoSection';
import { AppUsageSection } from './components/AppUsageSection';
import { SalTeaSection } from './components/SalTeaSection';
import { Dashboard } from './components/Dashboard';
import { AuraAIChat } from './components/AuraAIChat';
import { LoginPage } from './components/LoginPage';

type View = 'todos' | 'usage' | 'aura' | 'community' | 'dashboard';

export default function App() {
  const [view, setView] = useState<View>('todos');
  const [isDark, setIsDark] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState('');

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const handleLogin = (name: string) => {
    setUserName(name);
    setIsLoggedIn(true);
  };

  if (!isLoggedIn) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground pb-24">
      <div className="max-w-4xl mx-auto px-6 py-8">
        <header className="flex items-center justify-between mb-12 animate-in fade-in slide-in-from-top-4 duration-700">
          <div className="flex items-center gap-3">
            <img
              src="/src/imports/FlowWithME.jpg"
              alt="FlowState Logo"
              className="w-12 h-12 rounded-xl object-cover"
            />
            <div>
              <h1 className="text-[2rem] tracking-tight leading-none">FlowState</h1>
              <div className="text-sm text-muted-foreground">Welcome back, {userName}</div>
            </div>
          </div>
          <button
            onClick={() => setIsDark(!isDark)}
            className="p-2 hover:bg-muted rounded-lg transition-all hover:scale-110"
          >
            {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </header>

        <div className="pb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          {view === 'todos' && <TodoSection />}
          {view === 'usage' && <AppUsageSection />}
          {view === 'aura' && <AuraAIChat />}
          {view === 'community' && <SalTeaSection />}
          {view === 'dashboard' && <Dashboard userName={userName} />}
        </div>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 bg-background border-t border-border z-40 backdrop-blur-sm bg-background/95">
        <div className="max-w-4xl mx-auto px-2">
          <div className="flex items-center justify-around py-3">
            <button
              onClick={() => setView('todos')}
              className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-all ${
                view === 'todos' ? 'text-foreground scale-105' : 'text-muted-foreground hover:scale-105'
              }`}
            >
              <ListTodo className="w-5 h-5" />
              <span className="text-xs">Tasks</span>
            </button>

            <button
              onClick={() => setView('usage')}
              className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-all ${
                view === 'usage' ? 'text-foreground scale-105' : 'text-muted-foreground hover:scale-105'
              }`}
            >
              <Smartphone className="w-5 h-5" />
              <span className="text-xs">Usage</span>
            </button>

            <button
              onClick={() => setView('aura')}
              className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-all ${
                view === 'aura' ? 'text-foreground scale-105' : 'text-muted-foreground hover:scale-105'
              }`}
            >
              <div className={`${view === 'aura' ? 'animate-pulse' : ''}`}>
                <Sparkles className="w-5 h-5" />
              </div>
              <span className="text-xs">Aura AI</span>
            </button>

            <button
              onClick={() => setView('community')}
              className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-all ${
                view === 'community' ? 'text-foreground scale-105' : 'text-muted-foreground hover:scale-105'
              }`}
            >
              <Users className="w-5 h-5" />
              <span className="text-xs">Community</span>
            </button>

            <button
              onClick={() => setView('dashboard')}
              className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-all ${
                view === 'dashboard' ? 'text-foreground scale-105' : 'text-muted-foreground hover:scale-105'
              }`}
            >
              <User className="w-5 h-5" />
              <span className="text-xs">Profile</span>
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
}