import { useState } from 'react';
import { Smartphone, AlertCircle, BookOpen } from 'lucide-react';

interface AppUsage {
  name: string;
  time: number;
  icon: string;
  category: 'productive' | 'neutral' | 'distracting';
}

export function AppUsageSection() {
  const [journalEntry, setJournalEntry] = useState('');
  const [usageData] = useState<AppUsage[]>([
    { name: 'Instagram', time: 145, icon: '📷', category: 'distracting' },
    { name: 'Twitter', time: 92, icon: '🐦', category: 'distracting' },
    { name: 'VS Code', time: 320, icon: '💻', category: 'productive' },
    { name: 'Notion', time: 67, icon: '📝', category: 'productive' },
    { name: 'YouTube', time: 180, icon: '📺', category: 'distracting' },
  ]);

  const totalDistractingTime = usageData
    .filter(app => app.category === 'distracting')
    .reduce((sum, app) => sum + app.time, 0);

  const greyscaleEnabled = totalDistractingTime > 120;

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  return (
    <div className="space-y-6">
      <div className="animate-in fade-in slide-in-from-right-4 duration-500">
        <h2 className="text-muted-foreground mb-2">Screen Time</h2>
        <div className="flex items-baseline gap-3">
          <div className="text-[2.5rem] leading-none tracking-tight">
            {formatTime(totalDistractingTime)}
          </div>
          <div className="text-muted-foreground">wasted today</div>
        </div>
      </div>

      <div className="space-y-4">
        {totalDistractingTime > 120 && (
          <div className="flex items-start gap-3 p-4 bg-destructive/10 rounded-lg border border-destructive/20">
            <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
            <div className="flex-1 space-y-2">
              <div className="text-sm">Excessive screen time detected ({formatTime(totalDistractingTime)})</div>
              <div className="text-xs text-muted-foreground">
                ✓ Greyscale mode activated
              </div>
              <button className="text-xs px-3 py-1.5 bg-destructive text-destructive-foreground rounded hover:opacity-80 transition-opacity">
                Block Social Media Apps
              </button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {usageData.map((app, index) => (
            <div
              key={app.name}
              className="flex items-center gap-3 animate-in fade-in slide-in-from-right-2 duration-300"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="text-2xl">{app.icon}</div>
              <div className="flex-1">
                <div className="flex justify-between items-baseline mb-1">
                  <span>{app.name}</span>
                  <span className="text-muted-foreground text-sm">{formatTime(app.time)}</span>
                </div>
                <div className="h-1 bg-muted rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 ease-out ${
                      app.category === 'distracting' ? 'bg-destructive' :
                      app.category === 'productive' ? 'bg-chart-2' : 'bg-muted-foreground'
                    }`}
                    style={{ width: `${(app.time / 320) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-8 p-6 border border-border rounded-2xl bg-gradient-to-br from-muted/30 to-muted/10 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-300">
        <div className="flex items-center gap-2 mb-4">
          <BookOpen className="w-5 h-5 text-muted-foreground" />
          <h3>Daily Journal</h3>
        </div>
        <textarea
          value={journalEntry}
          onChange={(e) => setJournalEntry(e.target.value)}
          placeholder="Jot down your thoughts, reflections, or what you're grateful for today..."
          className="w-full h-32 px-4 py-3 bg-transparent border border-border rounded-lg outline-none focus:border-foreground transition-colors resize-none"
        />
        <div className="text-xs text-muted-foreground mt-2">
          {journalEntry.length} characters
        </div>
      </div>

      {greyscaleEnabled && (
        <div className="fixed inset-0 pointer-events-none z-50 mix-blend-saturation bg-white/50" />
      )}
    </div>
  );
}
