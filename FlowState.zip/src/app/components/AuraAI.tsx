import { useState } from 'react';
import { Sparkles, Send, X } from 'lucide-react';

interface Message {
  role: 'user' | 'ai';
  content: string;
}

export function AuraAI() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'ai', content: 'Hi! I\'m Aura, your productivity companion. How can I help you stay focused today?' }
  ]);
  const [input, setInput] = useState('');

  const sendMessage = () => {
    if (!input.trim()) return;

    const userMessage = input;
    setMessages([...messages, { role: 'user', content: userMessage }]);
    setInput('');

    setTimeout(() => {
      const responses = [
        'Let\'s break that down into smaller tasks. What\'s the first step?',
        'Great question! I suggest starting with a 25-minute focused work session.',
        'Based on your usage patterns, it might help to schedule this during your peak focus hours (9-11 AM).',
        'I\'ve noticed you work best in 90-minute blocks. Want to try that approach?',
        'Let\'s create a plan together. What\'s your most important goal for today?'
      ];
      const aiResponse = responses[Math.floor(Math.random() * responses.length)];
      setMessages(prev => [...prev, { role: 'ai', content: aiResponse }]);
    }, 800);
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-8 right-8 w-14 h-14 bg-foreground text-background rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform z-50"
      >
        <Sparkles className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className="fixed inset-x-4 bottom-24 sm:bottom-28 sm:right-8 sm:left-auto sm:w-96 h-[70vh] sm:h-[32rem] bg-background border border-border rounded-2xl shadow-2xl flex flex-col z-50">
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              <h3>Aura AI</h3>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 hover:bg-muted rounded"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                    msg.role === 'user'
                      ? 'bg-foreground text-background'
                      : 'bg-muted'
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 border-t border-border">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Ask Aura..."
                className="flex-1 px-4 py-2 bg-muted rounded-full outline-none text-sm"
              />
              <button
                onClick={sendMessage}
                className="w-10 h-10 bg-foreground text-background rounded-full flex items-center justify-center hover:opacity-80 transition-opacity flex-shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
