import { useState } from 'react';
import { Sparkles, Send } from 'lucide-react';

interface Message {
  role: 'user' | 'ai';
  content: string;
}

export function AuraAIChat() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'ai', content: 'Hi! I\'m Aura, your productivity companion. How can I help you stay focused today?' }
  ]);
  const [input, setInput] = useState('');

  const sendMessage = () => {
    if (!input.trim()) return;

    const userMessage = input.toLowerCase();
    setMessages(prev => [...prev, { role: 'user', content: input }]);
    setInput('');

    setTimeout(() => {
      let aiResponse = '';

      // Intelligent responses based on user input
      if (userMessage.includes('plan') || userMessage.includes('schedule') || userMessage.includes('organize')) {
        aiResponse = 'Here\'s a productive day plan:\n\n🌅 6:00-7:00 AM: Morning routine (meditation, exercise)\n🎯 9:00-11:00 AM: Deep work session (your peak focus time)\n☕ 11:00-11:15 AM: Short break\n📊 11:15 AM-1:00 PM: Meetings/collaboration\n🍱 1:00-2:00 PM: Lunch & rest\n⚡ 2:00-4:00 PM: Another deep work block\n📚 4:00-5:00 PM: Learning/admin tasks\n🌙 Evening: Reflect & plan tomorrow\n\nWant me to customize this?';
      } else if (userMessage.includes('focus') || userMessage.includes('concentrate') || userMessage.includes('distract')) {
        aiResponse = 'To boost focus, try this:\n\n1. Use the Pomodoro Technique (25 min work, 5 min break)\n2. Turn on "Do Not Disturb" mode\n3. Keep only one browser tab open\n4. Use noise-canceling headphones or lo-fi music\n5. Set clear goals before starting\n\nWant to start a focus session now?';
      } else if (userMessage.includes('task') || userMessage.includes('todo') || userMessage.includes('work')) {
        aiResponse = 'Let\'s organize your tasks:\n\n1. Brain dump everything you need to do\n2. Prioritize using Eisenhower Matrix (Urgent/Important)\n3. Start with ONE most important task\n4. Break big tasks into 30-min chunks\n5. Schedule difficult tasks for your peak hours (9-11 AM)\n\nWhat\'s your #1 priority right now?';
      } else if (userMessage.includes('motivat') || userMessage.includes('lazy') || userMessage.includes('procrastinat')) {
        aiResponse = 'Feeling stuck? Try the 2-minute rule:\n\nJust commit to working for 2 minutes. That\'s it. Often, starting is the hardest part. Once you begin, momentum builds naturally.\n\nRemember: You don\'t need to feel motivated to start. Motivation comes AFTER you take action. 💪\n\nWhat\'s one tiny step you can take right now?';
      } else if (userMessage.includes('break') || userMessage.includes('rest') || userMessage.includes('tired')) {
        aiResponse = 'Rest is productive too! Here\'s a quality break:\n\n✨ Stand up and stretch (2 min)\n💧 Drink water\n🪟 Look away from screens (20-20-20 rule)\n🚶 Take a short walk\n🧘 Do breathing exercises\n\nAvoid scrolling social media during breaks. Set a timer for 10-15 minutes and truly disconnect.';
      } else if (userMessage.includes('time') || userMessage.includes('hour') || userMessage.includes('when')) {
        aiResponse = 'Your peak productivity hours based on science:\n\n🌟 9:00-11:00 AM: Highest focus (tackle hardest tasks)\n📊 11:00 AM-1:00 PM: Good for meetings\n😴 1:00-3:00 PM: Post-lunch dip (admin work)\n⚡ 3:00-5:00 PM: Second wind (creative tasks)\n\nWork WITH your energy, not against it!';
      } else {
        const generalResponses = [
          'I\'m here to help you stay productive! Ask me about planning your day, staying focused, or overcoming procrastination. 🎯',
          'Tell me what you\'re working on today, and I\'ll help you create a plan to crush it! 💪',
          'Want to organize your tasks? Just say "help me plan my day" and I\'ll guide you through it.',
          'I can help with: daily planning, focus techniques, task prioritization, or motivation. What do you need? ✨',
        ];
        aiResponse = generalResponses[Math.floor(Math.random() * generalResponses.length)];
      }

      setMessages(prev => [...prev, { role: 'ai', content: aiResponse }]);
    }, 800);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-280px)] animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-foreground text-background rounded-full flex items-center justify-center animate-pulse">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-muted-foreground">Aura AI</h2>
            <div className="text-sm text-muted-foreground">Your productivity companion</div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}
            style={{ animationDelay: `${i * 50}ms` }}
          >
            <div
              className={`max-w-[85%] p-4 rounded-2xl ${
                msg.role === 'user'
                  ? 'bg-foreground text-background'
                  : 'bg-muted border border-border'
              }`}
            >
              {msg.content}
            </div>
          </div>
        ))}
      </div>

      <div className="border-t border-border pt-4">
        <div className="flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="Ask Aura anything..."
            className="flex-1 px-5 py-3 bg-muted rounded-full outline-none focus:ring-2 focus:ring-foreground/20 transition-all"
          />
          <button
            onClick={sendMessage}
            className="w-12 h-12 bg-foreground text-background rounded-full flex items-center justify-center hover:scale-110 transition-transform flex-shrink-0"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
