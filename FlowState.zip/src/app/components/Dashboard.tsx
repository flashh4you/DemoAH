import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Edit2, Award, Target, Flame, Github, Linkedin } from 'lucide-react';

interface DashboardProps {
  userName: string;
}

export function Dashboard({ userName }: DashboardProps) {
  const weekData = [
    { day: 'Mon', tasks: 8, focus: 180 },
    { day: 'Tue', tasks: 6, focus: 150 },
    { day: 'Wed', tasks: 10, focus: 240 },
    { day: 'Thu', tasks: 7, focus: 170 },
    { day: 'Fri', tasks: 9, focus: 200 },
    { day: 'Sat', tasks: 5, focus: 120 },
    { day: 'Sun', tasks: 4, focus: 90 },
  ];

  const stats = [
    { label: 'Current Streak', value: '12', unit: 'days', icon: Flame },
    { label: 'Tasks Completed', value: '342', unit: 'total', icon: Target },
    { label: 'Focus Time', value: '89', unit: 'hours', icon: Award },
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between animate-in fade-in slide-in-from-top-4 duration-500">
        <div>
          <h2 className="text-muted-foreground mb-2">Profile</h2>
          <div className="text-[2.5rem] leading-none tracking-tight mb-2">{userName}</div>
          <div className="text-muted-foreground">@{userName.toLowerCase().replace(/\s+/g, '')} • Member since Jan 2026</div>
        </div>
        <button className="p-2 hover:bg-muted rounded">
          <Edit2 className="w-5 h-5" />
        </button>
      </div>

      <div className="flex gap-3 animate-in fade-in slide-in-from-bottom-2 duration-500 delay-100">
        <button className="flex-1 p-3 border border-border rounded-lg hover:bg-muted transition-all hover:scale-105 flex items-center justify-center gap-2">
          <Github className="w-5 h-5" />
          <span>Connect GitHub</span>
        </button>
        <button className="flex-1 p-3 border border-border rounded-lg hover:bg-muted transition-all hover:scale-105 flex items-center justify-center gap-2">
          <Linkedin className="w-5 h-5" />
          <span>Connect LinkedIn</span>
        </button>
      </div>

      <div className="p-4 bg-muted/50 rounded-lg border border-border">
        <div className="text-sm text-muted-foreground mb-1">Bio</div>
        <div>
          Productivity enthusiast fighting procrastination one task at a time. Deep work believer.
          Building better habits with the FlowState community.
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {stats.map((stat, index) => (
          <div
            key={stat.label}
            className="p-4 border border-border rounded-lg hover:scale-105 transition-all cursor-pointer animate-in fade-in slide-in-from-bottom-2 duration-300"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <stat.icon className="w-5 h-5 mb-3 text-muted-foreground" />
            <div className="text-2xl mb-1">{stat.value}</div>
            <div className="text-xs text-muted-foreground">{stat.unit}</div>
            <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
          </div>
        ))}
      </div>

      <div>
        <h3 className="mb-4">This Week's Activity</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={weekData}>
              <CartesianGrid key="grid" strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis
                key="xaxis"
                dataKey="day"
                stroke="var(--muted-foreground)"
                tick={{ fill: 'var(--muted-foreground)' }}
              />
              <YAxis
                key="yaxis"
                stroke="var(--muted-foreground)"
                tick={{ fill: 'var(--muted-foreground)' }}
              />
              <Bar key="bar-tasks" dataKey="tasks" fill="var(--foreground)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div>
        <h3 className="mb-4">Achievements</h3>
        <div className="grid grid-cols-4 gap-3">
          {[
            { emoji: '🏆', id: 'trophy' },
            { emoji: '⚡', id: 'lightning' },
            { emoji: '🎯', id: 'target' },
            { emoji: '🔥', id: 'fire' },
            { emoji: '💪', id: 'muscle' },
            { emoji: '🌟', id: 'star' },
            { emoji: '🚀', id: 'rocket' },
            { emoji: '✨', id: 'sparkles' }
          ].map((item, i) => (
            <div
              key={item.id}
              className={`aspect-square flex items-center justify-center text-3xl border border-border rounded-lg ${
                i < 5 ? 'opacity-100' : 'opacity-20'
              }`}
            >
              {item.emoji}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
