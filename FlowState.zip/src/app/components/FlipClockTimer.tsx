import { useState, useEffect } from 'react';
import { Play, Pause, X, RotateCcw } from 'lucide-react';

interface FlipClockTimerProps {
  onEnterAuraMode: (duration: number) => void;
}

export function FlipClockTimer({ onEnterAuraMode }: FlipClockTimerProps) {
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(25);
  const [isRunning, setIsRunning] = useState(false);
  const [totalSeconds, setTotalSeconds] = useState(25 * 60);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && totalSeconds > 0) {
      interval = setInterval(() => {
        setTotalSeconds(prev => {
          if (prev <= 1) {
            setIsRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, totalSeconds]);

  useEffect(() => {
    setHours(Math.floor(totalSeconds / 3600));
    setMinutes(Math.floor((totalSeconds % 3600) / 60));
  }, [totalSeconds]);

  const handleStart = () => {
    if (!isRunning && totalSeconds > 0) {
      setIsRunning(true);
    }
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTotalSeconds(25 * 60);
  };

  const handleEnterAuraMode = () => {
    if (totalSeconds > 0) {
      setIsRunning(true);
      onEnterAuraMode(totalSeconds);
    }
  };

  const adjustTime = (type: 'hours' | 'minutes', increment: boolean) => {
    if (isRunning) return;

    const change = increment ? 1 : -1;
    if (type === 'hours') {
      const newHours = Math.max(0, Math.min(23, hours + change));
      setTotalSeconds(newHours * 3600 + minutes * 60);
    } else {
      const newMinutes = Math.max(0, Math.min(59, minutes + change));
      setTotalSeconds(hours * 3600 + newMinutes * 60);
    }
  };

  const displaySeconds = totalSeconds % 60;

  return (
    <div className="p-6 border border-border rounded-2xl bg-gradient-to-br from-muted/30 to-muted/10 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-300">
      <div className="text-sm text-muted-foreground mb-4 text-center">Focus Timer</div>

      <div className="flex items-center justify-center gap-2 mb-6">
        <div className="text-center">
          <div className="flex flex-col gap-1">
            <button
              onClick={() => adjustTime('hours', true)}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              disabled={isRunning}
            >
              ▲
            </button>
            <div className="relative">
              <div className="text-5xl font-light tabular-nums tracking-tight w-20 text-center bg-muted/50 rounded-lg py-3 backdrop-blur-sm border border-border/50">
                {String(hours).padStart(2, '0')}
              </div>
            </div>
            <button
              onClick={() => adjustTime('hours', false)}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              disabled={isRunning}
            >
              ▼
            </button>
          </div>
        </div>

        <div className="text-5xl font-light text-muted-foreground">:</div>

        <div className="text-center">
          <div className="flex flex-col gap-1">
            <button
              onClick={() => adjustTime('minutes', true)}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              disabled={isRunning}
            >
              ▲
            </button>
            <div className="relative">
              <div className="text-5xl font-light tabular-nums tracking-tight w-20 text-center bg-muted/50 rounded-lg py-3 backdrop-blur-sm border border-border/50">
                {String(minutes).padStart(2, '0')}
              </div>
            </div>
            <button
              onClick={() => adjustTime('minutes', false)}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              disabled={isRunning}
            >
              ▼
            </button>
          </div>
        </div>

        <div className="text-5xl font-light text-muted-foreground">:</div>

        <div className="text-center">
          <div className="flex flex-col gap-1">
            <div className="text-xs text-transparent">▲</div>
            <div className="relative">
              <div className="text-5xl font-light tabular-nums tracking-tight w-20 text-center bg-muted/50 rounded-lg py-3 backdrop-blur-sm border border-border/50">
                {String(displaySeconds).padStart(2, '0')}
              </div>
            </div>
            <div className="text-xs text-transparent">▼</div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-3">
        {!isRunning ? (
          <button
            onClick={handleStart}
            className="px-6 py-2 bg-foreground text-background rounded-full hover:scale-105 transition-all flex items-center gap-2"
          >
            <Play className="w-4 h-4" />
            <span>Start</span>
          </button>
        ) : (
          <button
            onClick={handlePause}
            className="px-6 py-2 bg-foreground text-background rounded-full hover:scale-105 transition-all flex items-center gap-2"
          >
            <Pause className="w-4 h-4" />
            <span>Pause</span>
          </button>
        )}

        <button
          onClick={handleReset}
          className="p-2 hover:bg-muted rounded-full transition-all hover:scale-110"
        >
          <RotateCcw className="w-5 h-5" />
        </button>
      </div>

      <button
        onClick={handleEnterAuraMode}
        className="w-full mt-4 py-3 bg-gradient-to-r from-purple-600 to-purple-800 text-white rounded-full hover:scale-105 transition-all font-medium"
      >
        Enter Aura Mode
      </button>
    </div>
  );
}

export function AuraModeFullscreen({ duration, onExit }: { duration: number; onExit: () => void }) {
  const [timeLeft, setTimeLeft] = useState(duration);

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          onExit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [onExit]);

  const hours = Math.floor(timeLeft / 3600);
  const minutes = Math.floor((timeLeft % 3600) / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="fixed inset-0 bg-black z-[100] flex items-center justify-center">
      <button
        onClick={onExit}
        className="absolute top-8 right-8 p-3 text-white/60 hover:text-white transition-colors"
      >
        <X className="w-6 h-6" />
      </button>

      <div className="text-center space-y-8">
        <div className="text-white/60 text-xl tracking-wider">AURA MODE</div>

        <div className="flex items-center justify-center gap-4">
          <div className="text-center">
            <div className="text-[8rem] font-extralight text-white tabular-nums tracking-tight">
              {String(hours).padStart(2, '0')}
            </div>
          </div>
          <div className="text-[8rem] font-extralight text-white/40">:</div>
          <div className="text-center">
            <div className="text-[8rem] font-extralight text-white tabular-nums tracking-tight">
              {String(minutes).padStart(2, '0')}
            </div>
          </div>
          <div className="text-[8rem] font-extralight text-white/40">:</div>
          <div className="text-center">
            <div className="text-[8rem] font-extralight text-white tabular-nums tracking-tight">
              {String(seconds).padStart(2, '0')}
            </div>
          </div>
        </div>

        <div className="text-white/40 text-lg">Stay focused. You got this.</div>
      </div>
    </div>
  );
}
