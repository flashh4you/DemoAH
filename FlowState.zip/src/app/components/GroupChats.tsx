import { useState } from 'react';
import { MessageCircle, Send, Users, ArrowLeft } from 'lucide-react';

interface GroupChat {
  id: string;
  name: string;
  members: number;
  lastMessage: string;
  unread: number;
}

interface Message {
  id: string;
  sender: string;
  content: string;
  time: string;
}

export function GroupChats() {
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [message, setMessage] = useState('');

  const [chats] = useState<GroupChat[]>([
    { id: '1', name: 'Deep Work Warriors', members: 45, lastMessage: 'Just finished 3hr session!', unread: 3 },
    { id: '2', name: 'Morning Hustlers', members: 67, lastMessage: 'Who\'s up for 5AM club?', unread: 0 },
    { id: '3', name: 'Code & Focus', members: 89, lastMessage: 'Pomodoro technique working great', unread: 7 },
    { id: '4', name: 'Accountability Squad', members: 34, lastMessage: 'Check-in time! What did you achieve?', unread: 2 },
  ]);

  const [messages] = useState<Message[]>([
    { id: '1', sender: 'Priya Patel', content: 'Just finished 3hr session! Feeling amazing 🔥', time: '10:30' },
    { id: '2', sender: 'Arjun Mehta', content: 'That\'s awesome! What were you working on?', time: '10:32' },
    { id: '3', sender: 'Priya Patel', content: 'Client project. Used the 2-hour deep work block technique', time: '10:33' },
    { id: '4', sender: 'Rohan Verma', content: 'Nice! I\'m about to start mine now', time: '10:35' },
  ]);

  const sendMessage = () => {
    if (message.trim()) {
      setMessage('');
    }
  };

  if (selectedChat) {
    const chat = chats.find(c => c.id === selectedChat);
    return (
      <div className="flex flex-col h-full">
        <div className="flex items-center gap-3 p-4 border-b border-border">
          <button
            onClick={() => setSelectedChat(null)}
            className="p-2 hover:bg-muted rounded-lg"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <div>{chat?.name}</div>
            <div className="text-sm text-muted-foreground flex items-center gap-1">
              <Users className="w-3 h-3" />
              {chat?.members} members
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className="space-y-1">
              <div className="flex items-baseline gap-2">
                <span className="text-sm">{msg.sender}</span>
                <span className="text-xs text-muted-foreground">{msg.time}</span>
              </div>
              <div className="bg-muted p-3 rounded-lg inline-block max-w-[80%]">
                {msg.content}
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-border">
          <div className="flex gap-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              placeholder="Type a message..."
              className="flex-1 px-4 py-2 bg-muted rounded-lg outline-none"
            />
            <button
              onClick={sendMessage}
              className="w-10 h-10 bg-foreground text-background rounded-lg flex items-center justify-center hover:opacity-80"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 mb-4">
        <MessageCircle className="w-4 h-4" />
        <h3 className="text-sm">Group Chats</h3>
      </div>

      {chats.map((chat) => (
        <button
          key={chat.id}
          onClick={() => setSelectedChat(chat.id)}
          className="w-full text-left p-4 rounded-lg border border-border hover:bg-muted transition-colors"
        >
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span>{chat.name}</span>
                {chat.unread > 0 && (
                  <span className="bg-destructive text-destructive-foreground text-xs px-2 py-0.5 rounded-full">
                    {chat.unread}
                  </span>
                )}
              </div>
              <div className="text-sm text-muted-foreground">{chat.lastMessage}</div>
            </div>
          </div>
          <div className="text-xs text-muted-foreground flex items-center gap-1">
            <Users className="w-3 h-3" />
            {chat.members} members
          </div>
        </button>
      ))}

      <button className="w-full py-3 border border-dashed border-foreground/20 rounded-lg hover:bg-muted transition-colors">
        + Create New Group
      </button>
    </div>
  );
}
