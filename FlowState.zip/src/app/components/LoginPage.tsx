import { useState } from 'react';
import { Sparkles } from 'lucide-react';

interface LoginPageProps {
  onLogin: (name: string) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [isSignup, setIsSignup] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() || email.trim()) {
      onLogin(name.trim() || email.split('@')[0]);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center px-6">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center space-y-4 animate-in fade-in slide-in-from-top-8 duration-700">
          <img
            src="/src/imports/FlowWithME.jpg"
            alt="FlowState Logo"
            className="w-24 h-24 mx-auto rounded-2xl object-cover mb-4 shadow-lg"
          />
          <h1 className="text-[3rem] leading-none tracking-tight">FlowState</h1>
          <p className="text-muted-foreground">
            Stop doomscrolling. Start achieving.
          </p>
          <p className="text-sm text-muted-foreground">by Team Quint</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
          {isSignup && (
            <div>
              <label className="block text-sm text-muted-foreground mb-2">Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Rahul Sharma"
                className="w-full px-4 py-3 bg-transparent border border-border rounded-lg focus:border-foreground outline-none transition-colors"
              />
            </div>
          )}

          <div>
            <label className="block text-sm text-muted-foreground mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-4 py-3 bg-transparent border border-border rounded-lg focus:border-foreground outline-none transition-colors"
              required
            />
          </div>

          <div>
            <label className="block text-sm text-muted-foreground mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-3 bg-transparent border border-border rounded-lg focus:border-foreground outline-none transition-colors"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-foreground text-background rounded-lg hover:opacity-90 hover:scale-105 transition-all"
          >
            {isSignup ? 'Create Account' : 'Sign In'}
          </button>
        </form>

        <div className="text-center">
          <button
            onClick={() => setIsSignup(!isSignup)}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            {isSignup ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
          </button>
        </div>

        <div className="text-center pt-6 border-t border-border">
          <p className="text-xs text-muted-foreground">
            Join 1000+ people reclaiming their focus and productivity
          </p>
        </div>
      </div>
    </div>
  );
}
