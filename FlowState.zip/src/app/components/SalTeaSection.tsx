import { useState } from 'react';
import { Users, TrendingUp, MessageSquare } from 'lucide-react';
import { GroupChats } from './GroupChats';

interface Member {
  id: string;
  name: string;
  avatar: string;
  streak: number;
  tasksCompleted: number;
}

interface SharedGoal {
  id: string;
  title: string;
  participants: number;
  progress: number;
}

type CommunityView = 'overview' | 'groups';

export function SalTeaSection() {
  const [view, setView] = useState<CommunityView>('overview');
  const [members] = useState<Member[]>([
    { id: '1', name: 'Shibashis Bhattacharjee', avatar: '👨‍💻', streak: 12, tasksCompleted: 8 },
    { id: '2', name: 'Sayanta Misra', avatar: '🧑‍💼', streak: 8, tasksCompleted: 6 },
    { id: '3', name: 'Amulya Vibhav', avatar: '👨‍🎨', streak: 15, tasksCompleted: 10 },
    { id: '4', name: 'Souradeep Shil', avatar: '🧑‍🔬', streak: 5, tasksCompleted: 4 },
    { id: '5', name: 'Shivam Kumar', avatar: '👨‍💼', streak: 9, tasksCompleted: 7 },
  ]);

  const [sharedGoals] = useState<SharedGoal[]>([
    { id: '1', title: '30-Day Deep Work Challenge', participants: 127, progress: 42 },
    { id: '2', title: 'Social Media Detox', participants: 89, progress: 68 },
    { id: '3', title: 'Morning Routine Masters', participants: 203, progress: 55 },
  ]);

  if (view === 'groups') {
    return (
      <div className="space-y-4">
        <button
          onClick={() => setView('overview')}
          className="text-sm text-muted-foreground hover:text-foreground"
        >
          ← Back to Community
        </button>
        <GroupChats />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
        <h2 className="text-muted-foreground mb-4">SalTea Community</h2>
        <div className="text-sm text-muted-foreground mb-6">
          Connect with {members.length + 156} people building better habits
        </div>
      </div>

      <button
        onClick={() => setView('groups')}
        className="w-full p-4 bg-foreground text-background rounded-lg hover:opacity-90 hover:scale-105 transition-all flex items-center justify-center gap-2 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-100"
      >
        <MessageSquare className="w-5 h-5" />
        <span>Open Group Chats</span>
      </button>

      <div>
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-4 h-4" />
          <h3 className="text-sm">Shared Goals</h3>
        </div>
        <div className="space-y-4">
          {sharedGoals.map((goal, index) => (
            <div
              key={goal.id}
              className="p-4 border border-border rounded-lg hover:bg-muted/50 transition-all cursor-pointer hover:scale-105 animate-in fade-in slide-in-from-bottom-2 duration-300"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <div className="mb-1">{goal.title}</div>
                  <div className="text-sm text-muted-foreground flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    {goal.participants} participants
                  </div>
                </div>
                <button className="px-3 py-1 text-xs border border-foreground/20 rounded hover:bg-foreground hover:text-background transition-all hover:scale-110">
                  Join
                </button>
              </div>
              <div className="space-y-1">
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-foreground transition-all"
                    style={{ width: `${goal.progress}%` }}
                  />
                </div>
                <div className="text-xs text-muted-foreground">{goal.progress}% complete</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-4 h-4" />
          <h3 className="text-sm">Active Members</h3>
        </div>
        <div className="space-y-2">
          {members.map(member => (
            <div key={member.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors cursor-pointer">
              <div className="text-3xl">{member.avatar}</div>
              <div className="flex-1">
                <div className="mb-0.5">{member.name}</div>
                <div className="text-sm text-muted-foreground">
                  🔥 {member.streak} day streak • {member.tasksCompleted} tasks today
                </div>
              </div>
              <button className="p-2 hover:bg-muted-foreground/10 rounded">
                <MessageSquare className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <button className="w-full py-3 border border-foreground/20 rounded-lg hover:bg-foreground hover:text-background transition-colors">
        Explore Community
      </button>
    </div>
  );
}
