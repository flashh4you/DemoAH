import { useState } from 'react';
import { Check, Plus, X } from 'lucide-react';
import { FlipClockTimer, AuraModeFullscreen } from './FlipClockTimer';

interface Todo {
  id: string;
  text: string;
  completed: boolean;
}

export function TodoSection() {
  const [isAuraMode, setIsAuraMode] = useState(false);
  const [auraDuration, setAuraDuration] = useState(0);
  const [todos, setTodos] = useState<Todo[]>([
    { id: '1', text: 'Morning meditation', completed: true },
    { id: '2', text: 'Deep work session (2hrs)', completed: true },
    { id: '3', text: 'Gym workout', completed: false },
    { id: '4', text: 'Read 30 pages', completed: false },
    { id: '5', text: 'Evening journal', completed: false },
  ]);
  const [newTodo, setNewTodo] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const completedCount = todos.filter(t => t.completed).length;
  const progress = todos.length > 0 ? (completedCount / todos.length) * 100 : 0;

  const toggleTodo = (id: string) => {
    setTodos(todos.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const addTodo = () => {
    if (newTodo.trim()) {
      setTodos([...todos, { id: Date.now().toString(), text: newTodo, completed: false }]);
      setNewTodo('');
      setIsAdding(false);
    }
  };

  const removeTodo = (id: string) => {
    setTodos(todos.filter(t => t.id !== id));
  };

  const handleEnterAuraMode = (duration: number) => {
    setAuraDuration(duration);
    setIsAuraMode(true);
  };

  return (
    <>
      {isAuraMode && (
        <AuraModeFullscreen
          duration={auraDuration}
          onExit={() => setIsAuraMode(false)}
        />
      )}
      <div className="space-y-6">
      <div className="animate-in fade-in slide-in-from-left-4 duration-500">
        <h2 className="text-muted-foreground mb-2">Today</h2>
        <div className="flex items-baseline gap-3">
          <div className="text-[2.5rem] leading-none tracking-tight">
            {completedCount}/{todos.length}
          </div>
          <div className="text-muted-foreground">tasks</div>
        </div>
      </div>

      <div className="space-y-2 animate-in fade-in slide-in-from-left-4 duration-500 delay-100">
        <div className="h-1 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-foreground transition-all duration-500 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="text-sm text-muted-foreground">{Math.round(progress)}% complete</div>
      </div>

      <div className="space-y-2">
        {todos.map((todo, index) => (
          <div
            key={todo.id}
            className="flex items-center gap-3 group py-2 animate-in fade-in slide-in-from-left-2 duration-300"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <button
              onClick={() => toggleTodo(todo.id)}
              className="w-5 h-5 rounded-full border-2 border-foreground flex items-center justify-center flex-shrink-0 transition-all hover:bg-muted hover:scale-110"
            >
              {todo.completed && <Check className="w-3 h-3 animate-in zoom-in duration-200" />}
            </button>
            <span className={`flex-1 transition-all duration-300 ${todo.completed ? 'opacity-40 line-through' : ''}`}>
              {todo.text}
            </span>
            <button
              onClick={() => removeTodo(todo.id)}
              className="opacity-0 group-hover:opacity-100 transition-all p-1 hover:bg-muted rounded hover:scale-110"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {isAdding ? (
        <div className="flex gap-2">
          <input
            type="text"
            value={newTodo}
            onChange={(e) => setNewTodo(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addTodo()}
            placeholder="New task..."
            className="flex-1 bg-transparent border-b border-foreground/20 focus:border-foreground outline-none py-1"
            autoFocus
          />
          <button onClick={addTodo} className="px-3 py-1 hover:bg-muted rounded">Add</button>
          <button onClick={() => setIsAdding(false)} className="px-3 py-1 hover:bg-muted rounded">Cancel</button>
        </div>
      ) : (
        <button
          onClick={() => setIsAdding(true)}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add task</span>
        </button>
      )}

      <FlipClockTimer onEnterAuraMode={handleEnterAuraMode} />
    </div>
    </>
  );
}
